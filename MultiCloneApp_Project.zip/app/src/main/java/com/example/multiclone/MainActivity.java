package com.example.multiclone;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btnSelectApp, btnRunAll;
    private TextView txtSelectedApp;
    private String selectedPackageName = "";

    private List<ApplicationInfo> appList;
    private String[] appNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSelectApp = findViewById(R.id.btnSelectApp);
        btnRunAll = findViewById(R.id.btnRunAll);
        txtSelectedApp = findViewById(R.id.txtSelectedApp);

        btnSelectApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAppSelectionDialog();
            }
        });

        btnRunAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPackageName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Pehle ek App select karein!", Toast.LENGTH_SHORT).show();
                } else {
                    launch4Clones();
                }
            }
        });
    }

    private void showAppSelectionDialog() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        
        List<String> names = new ArrayList<>();
        appList = new ArrayList<>();

        for (ApplicationInfo packageInfo : packages) {
            // Filter out system apps
            if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                names.add(pm.getApplicationLabel(packageInfo).toString());
                appList.add(packageInfo);
            }
        }

        appNames = names.toArray(new String[0]);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("App Select Karein");
        builder.setItems(appNames, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                selectedPackageName = appList.get(which).packageName;
                txtSelectedApp.setText("Selected App: " + appNames[which]);
            }
        });
        builder.show();
    }

    private void launch4Clones() {
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage(selectedPackageName);

        if (launchIntent != null) {
            Toast.makeText(this, "4 Instances/Clones Run Ho Rahe Hain...", Toast.LENGTH_SHORT).show();
            
            // Multi-window flag request
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            startActivity(launchIntent);
        } else {
            Toast.makeText(this, "Yeh App Launch Nahi Ho Sakti!", Toast.LENGTH_SHORT).show();
        }
    }
}
